# Variables in R
a <- 10
b = 20
30 -> c
print(a)
b
cat(c)
ls()
rm(b)
print(b)