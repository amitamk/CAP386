# More about Vectors
primes <- c(1,2,3,5,7,11,13) # well...
primes
flags <- c(FALSE,FALSE,TRUE,FALSE)
mode(primes)
mode(flags)
length(primes)
length(flags)
