a <- 10
b = 20
30 -> c
print(c)