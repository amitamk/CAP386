# Primitive Data Types
l <- FALSE
n <- 12.333
i <- 64L
cx <- 3+2i
cc <- 'programming'
class(l) 
class(n)
class(i)
class(cx)
class(cc)