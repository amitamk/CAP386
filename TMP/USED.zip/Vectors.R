# Vectors
l <- c(FALSE,FALSE,TRUE,FALSE)
n <- c(12.333,12.389,12.918,13,14.021)
cc <- c('programming','r','python')
class(l) 
class(n)
class(cc)
mode(l)
mode(n)
mode(cc)

